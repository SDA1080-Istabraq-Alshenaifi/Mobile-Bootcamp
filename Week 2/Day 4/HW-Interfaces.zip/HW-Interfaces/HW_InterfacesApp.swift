//
//  HW_InterfacesApp.swift
//  HW-Interfaces
//
//  Created by istabraq on 19/07/1445 AH.
//

import SwiftUI

@main
struct HW_InterfacesApp: App {
    var body: some Scene {
        WindowGroup {
            Login_interface()
        }
    }
}
